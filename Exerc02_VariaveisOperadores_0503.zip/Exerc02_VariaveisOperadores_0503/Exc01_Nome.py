nome = "João"
print(nome)